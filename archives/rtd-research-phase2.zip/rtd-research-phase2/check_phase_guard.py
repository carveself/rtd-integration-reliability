"""Post-review diagnostic, not a retuned or prospectively validated algorithm.

Audit whether a half-panel shifted independent initialization detects point-error
undercoverage in already-computed goal results. Adds its full evaluation cost.
"""
from pathlib import Path
import sys,json,csv,argparse
import numpy as np
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'src'))
from models import model
from integration import PanelIntegral
from negf import current_prefactor,KB,Q


def alternate(d,case,cfg):
 st=PanelIntegral.__new__(PanelIntegral)
 st.device=d;st.bias=case['bias_V'];st.temp=case['temperature_K'];st.cfg=cfg;st.evaluations=0;st.refinements=0;st.pref=current_prefactor(d.mass)
 vt=KB*st.temp/Q;lo=max(0.,-st.bias)+1e-12;hi=max(d.mu_eV,d.mu_eV-st.bias)+30*vt
 st.tail=st.pref*vt**2*(np.exp((d.mu_eV-hi)/vt)+np.exp((d.mu_eV-st.bias-hi)/vt))
 count=int(np.ceil((hi-lo)/cfg['initial_panel_eV']));width=(hi-lo)/count
 edges=np.r_[lo,lo+(np.arange(count)+.5)*width,hi]
 st.l=edges[:-1];st.r=edges[1:];st.v,st.e=st.panels(st.l,st.r)
 return st


def run(results=None):
 output=Path(results) if results is not None else root/'results'
 cfg=json.loads((root/'protocol.json').read_text());catalog={}
 for split in ['development','holdout','confirmation']:
  for case in cfg[split]:
   hs=np.random.default_rng(case['seed']).normal(.28,cfg['height_sigma_eV'],cfg['samples'])
   catalog[case['id']]=(case,[model(case,height=float(h)) for h in hs])
 for case in cfg['designs']:catalog[case['id']]=(case,[model(case,well=w) for w in case['wells_nm']])
 rows=list(csv.DictReader((output/'sample_errors.csv').open()));out=[]
 for r in rows:
  if r['method']!='goal':continue
  case,models=catalog[r['context']];st=alternate(models[int(r['item'])],case,cfg)
  before=float(r['estimated_error_A_m2']);y=float(r['J_A_m2']);actual=float(r['actual_abs_error_A_m2'])
  guard=max(before,st.error,abs(y-st.value))
  out.append(dict(context=r['context'],item=r['item'],actual_error_A_m2=actual,original_estimated_error_A_m2=before,
                  phase_guard_error_A_m2=guard,covered_before=actual<=before,covered_after=actual<=guard,
                  additional_energy_evaluations=st.evaluations))
 with (output/'phase_guard_audit.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
 original=sum(int(r['energy_evaluations']) for r in csv.DictReader((output/'benchmark.csv').open()) if r['method']=='goal')
 result=dict(status='post-review diagnostic on already-seen cases; no prospective validation or certificate',items=len(out),
             uncovered_before=sum(not r['covered_before'] for r in out),uncovered_after=sum(not r['covered_after'] for r in out),
             added_energy_evaluations=sum(r['additional_energy_evaluations'] for r in out),original_goal_energy_evaluations=original,
             added_fraction=sum(r['additional_energy_evaluations'] for r in out)/original)
 (output/'phase_guard_summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--results',type=Path);args=parser.parse_args();run(args.results)
