from pathlib import Path
import sys,json,hashlib,platform,importlib.metadata as md
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'src'))
from benchmark import run
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=root/'results');a=p.parse_args()
 cfg=json.loads((root/'protocol.json').read_text());result=run(a.output,cfg)
 files=[root/'run_phase2.py',root/'protocol.json',*[f for folder in ['src','vendor'] for f in (root/folder).glob('*.py')]]
 (a.output/'provenance.json').write_text(json.dumps({str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},indent=2)+'\n')
 (a.output/'environment.json').write_text(json.dumps({'python':platform.python_version(),**{k:md.version(k) for k in ['numpy','scipy','matplotlib']}},indent=2)+'\n')
 print(json.dumps(result,indent=2))
