# RTD研究第二轮：方法原型、强基线与导师视角修订

**已完成11个任务的比较研究和内部审阅；结论是继续研究，暂缓投稿。**

先读 [结果与修订结论](docs/RESULTS_AND_REVISION.md)，再读 [导师视角内部审阅](docs/ADVISOR_REVIEW.md)。这是研究标准的模拟审阅，不是真实导师意见。

本轮实现目标量驱动求积，与开发集调参、保守容差和统一目标预算调度比较。CV（Coefficient of Variation，变异系数）用于衡量固定样本的相对离散程度。包含新种子、77–350K、多个偏压、三势垒/双量子阱；13项针对性测试通过。具体证据、反例和修订过程均保留。

主要发现：验证集合计能量点评估数相对同目标预算强基线只减少约2.10%；5/308项误差估计漏覆盖；事后相位检查消除了本批漏覆盖，但额外计算约86.6%。因此当前不能称为具有保证的高效新算法。

## 复现

Python 3.10+：

```bash
python -m pip install -r requirements.txt
python run_phase2.py --output reproduction/full
python analyze_results.py --results reproduction/full
python check_phase_guard.py --results reproduction/full
python -m unittest discover -s tests -v
```

主流程默认输出results/，会覆盖同名文件；相对输出目录基于执行目录。省略--output及--results即可重建默认结果。环境版本在results/environment.json，数值运行源文件哈希在results/provenance.json，全包清单在MANIFEST.sha256。

## 阅读顺序

- [方法与对照设计](docs/METHODS.md)：条件误差区间、开发/留出隔离、成本计数和参考边界。
- [英文研究简报草稿](docs/MANUSCRIPT_DRAFT.md)：已按实际负结果收缩题目、摘要和结论，非投稿稿。
- [新增文献约束](docs/LITERATURE_UPDATE.md)：目标量自适应已有先例；未实现的文献方法明确列为缺口。
- [下一轮立项门槛](docs/NEXT_GATE.md)：可靠误差指示器与完整成本，不优先堆参数曲线。

## 数据与历史

results/包含全部方法的点误差、目标误差、计数与单次计时；goal_trajectories.json保存停机轨迹。undercoverage.csv保留失败项，phase_guard_audit.csv保留事后诊断。

protocol_round1.json、src_round1/和results_round1/保留首轮冻结设置、源码和原始输出。首轮设计记录中的estimated_target列曾误填所选参考电流，最终版已修正；选择和损失指标不受影响，分析使用最终版。

统一目标预算基线是在看过首轮后补充的，因此原6个留出任务对这项比较不再视为未见；另增2个新确认任务。近零模式的实现修正只在合成测试中检验，实际器件任务未覆盖近零总体变异。

这是给定电势、常质量、相干模型的数值方法研究。随机高度分布是合成假设，不是工艺测量。没有电荷自洽、实验、商业软件验证或投稿。代码和文本由工具辅助完成，个人后续贡献需按实际工作记录。
