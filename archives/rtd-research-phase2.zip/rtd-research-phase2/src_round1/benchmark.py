from pathlib import Path
import csv,json,time,hashlib,sys
from dataclasses import replace
import numpy as np
from scipy.signal import find_peaks
from scipy.integrate import quad
from models import model
from integration import PanelIntegral
from targets import coefficient_of_variation,goal_cv,goal_decision,current_arrays
from negf import integrate_current,transport,supply,current_prefactor
from reference import direct_banded
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def csv_write(path,rows):
 with Path(path).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def refs(models,case,cfg):
 values=[];rows=[]
 for i,d in enumerate(models):
  a=integrate_current(d,case['bias_V'],case['temperature_K'],rtol=cfg['reference_rtol'],panel_eV=cfg['reference_panel_eV'])
  b=integrate_current(d,case['bias_V'],case['temperature_K'],rtol=cfg['reference_rtol'],panel_eV=cfg['reference_check_panel_eV'])
  delta=abs(a['J_A_m2']/b['J_A_m2']-1)
  if delta>1e-6:raise RuntimeError(f'Reference inconsistency {case["id"]} {delta}')
  values.append(a['J_A_m2']);rows.append(dict(context=case['id'],item=i,J_A_m2=float(a['J_A_m2']),reference_panel_difference=delta))
 return np.array(values),rows


def states_for(models,case,cfg):return [PanelIntegral(d,case['bias_V'],case['temperature_K'],cfg) for d in models]


def measure(models,case,cfg,method,task,rtol=None):
 t=time.perf_counter();states=states_for(models,case,cfg)
 if method=='goal':out=goal_cv(states,cfg) if task=='cv' else goal_decision(states,cfg)
 else:
  for st in states:st.finish(rtol)
  y,_=current_arrays(states)
  out={'estimate':coefficient_of_variation(y)} if task=='cv' else {'chosen':int(np.argmax(y))}
 elapsed=time.perf_counter()-t;y,e=current_arrays(states)
 return out,y,e,sum(s.evaluations for s in states),elapsed


def assess(method,case,split,task,rtol,models,reference,cfg,trajectory):
 out,y,e,count,seconds=measure(models,case,cfg,method,task,rtol)
 err=np.abs(y-reference)
 if task=='cv':
  target=coefficient_of_variation(reference);estimate=coefficient_of_variation(y)
  actual_error=abs(estimate-target)/target if target>=cfg['cv_near_zero'] else abs(estimate-target)
  budget=cfg['cv_relative_budget'] if target>=cfg['cv_near_zero'] else cfg['cv_absolute_budget']
  chosen=-1;regret=0.;envelope_contains=bool(out.get('lower',-np.inf)<=target<=out.get('upper',np.inf))
 else:
  target=float(np.max(reference));chosen=out['chosen'];estimate=float(reference[chosen]);regret=float(1-reference[chosen]/target)
  actual_error=regret;budget=cfg['decision_regret_budget'];envelope_contains=bool(out.get('regret_estimate',np.inf)+1e-12>=regret)
 row=dict(context=case['id'],split=split,task=task,method=method,rtol='' if rtol is None else rtol,
          energy_evaluations=count,seconds=seconds,reference_target=target,estimated_target=estimate,
          actual_target_error=actual_error,budget=budget,passed=bool(actual_error<=budget),chosen=chosen,
          selection_regret=regret,point_error_coverage=float(np.mean(err<=e)),
          max_error_to_estimate_ratio=float(np.max(err/np.maximum(e,1e-30))),
          goal_envelope_contains_reference=envelope_contains if method=='goal' else '')
 details=[dict(context=case['id'],task=task,method=method,rtol='' if rtol is None else rtol,item=i,
               reference_J_A_m2=float(reference[i]),J_A_m2=float(y[i]),estimated_error_A_m2=float(e[i]),
               actual_abs_error_A_m2=float(err[i])) for i in range(len(y))]
 if method=='goal':trajectory[f'{task}/{case["id"]}']=out['trajectory']
 return row,details,out


def audit(models,case,cfg):
 # One central sample/candidate per context, selected by position rather than error.
 d=models[len(models)//2];v=case['bias_V'];temp=case['temperature_K']
 ref=integrate_current(d,v,temp,rtol=1e-9,panel_eV=.0005)
 hi=ref['Emax_eV'];es=np.linspace(1e-9,hi,5001);ts=transport(d,es,v)['T']
 ids,_=find_peaks(ts,prominence=1e-5);points=np.unique(np.r_[np.linspace(0,hi,151)[1:-1],es[ids]])
 f=lambda e:float(transport(d,[e],v)['T'][0]*supply(e,v,temp,d.mu_eV))
 val,error=quad(f,0.,hi,points=points,epsabs=1e-13,epsrel=1e-8,limit=2000)
 q=val*current_prefactor(d.mass)
 fine=integrate_current(replace(d,spacing_nm=.05),v,temp,rtol=1e-9,panel_eV=.0005)
 delta=abs(direct_banded(d,.035,v)-transport(d,[.035],v)['T'][0])
 return dict(context=case['id'],spectrum_peak_count=int(len(ids)),quad_reference_relative_difference=float(abs(q/ref['J_A_m2']-1)),
             mesh_relative_difference=float(abs(ref['J_A_m2']/fine['J_A_m2']-1)),direct_T_difference=float(delta))


def run(root,cfg):
 root=Path(root);root.mkdir(parents=True,exist_ok=True);rows=[];details=[];reference_rows=[];trajectories={};audits=[];catalog={}
 contexts=[]
 for split in ['development','holdout']:
  for case in cfg[split]:
   hs=np.random.default_rng(case['seed']).normal(.28,cfg['height_sigma_eV'],cfg['samples'])
   models=[model(case,height=float(h)) for h in hs]
   contexts.append((case,split,'cv',models))
 for case in cfg['designs']:
  contexts.append((case,case['split'],'decision',[model(case,well=w) for w in case['wells_nm']]))
 # All context/model choices fixed in protocol before this run. References not passed to stopping rules.
 for case,split,task,models in contexts:
  reference,rr=refs(models,case,cfg);reference_rows.extend(rr)
  catalog[case['id']]=(reference,models,case,split,task)
  if split=='development':
   for rtol in cfg['baseline_rtol_grid']:
    row,dd,_=assess('uniform-current-tolerance',case,split,task,rtol,models,reference,cfg,trajectories);rows.append(row);details.extend(dd)
  print('Reference prepared:',case['id'],flush=True)
 # Tuning can inspect development reference targets. Holdout targets never affect tolerance choice.
 selection={}
 for task in ['cv','decision']:
  candidates=[]
  for rtol in cfg['baseline_rtol_grid']:
   rr=[r for r in rows if r['task']==task and r['rtol']==rtol]
   if rr and all(r['passed'] for r in rr):candidates.append((sum(r['energy_evaluations'] for r in rr),-rtol,rtol))
  if not candidates:raise RuntimeError('No baseline tolerance passes development')
  selection[task]=min(candidates)[2]
 (root/'frozen_baseline_selection.json').write_text(json.dumps({'selected_rtol':selection,'rule':'cheapest energy-count tolerance passing all development contexts; larger tolerance breaks ties'},indent=2)+'\n')
 for cid,(reference,models,case,split,task) in catalog.items():
  for method,rtol in [('goal',None),('tuned-baseline',selection[task]),('conservative-baseline',1e-6)]:
   row,dd,out=assess(method,case,split,task,rtol,models,reference,cfg,trajectories);rows.append(row);details.extend(dd)
  audits.append(audit(models,case,cfg));print('Benchmarked:',cid,flush=True)
 csv_write(root/'benchmark.csv',rows);csv_write(root/'sample_errors.csv',details);csv_write(root/'references.csv',reference_rows);csv_write(root/'reference_audit.csv',audits)
 (root/'goal_trajectories.json').write_text(json.dumps(trajectories,indent=2)+'\n')
 pairs=[]
 for cid,(reference,models,case,split,task) in catalog.items():
  gg=next(r for r in rows if r['context']==cid and r['method']=='goal');bb=next(r for r in rows if r['context']==cid and r['method']=='tuned-baseline')
  pairs.append(dict(context=cid,split=split,task=task,goal_passed=gg['passed'],baseline_passed=bb['passed'],
                    baseline_over_goal_energy_cost=bb['energy_evaluations']/gg['energy_evaluations'],
                    baseline_over_goal_wall_time=bb['seconds']/gg['seconds'],goal_error=gg['actual_target_error'],baseline_error=bb['actual_target_error']))
 csv_write(root/'comparison.csv',pairs)
 held=[r for r in rows if r['split']=='holdout' and r['method']=='goal'];hp=[p for p in pairs if p['split']=='holdout']
 summary=dict(status='exploratory phase-2 evidence, novelty unresolved; estimated envelopes are not certificates',
              contexts=len(catalog),holdout_contexts=len(held),goal_holdout_passes=sum(r['passed'] for r in held),
              tuned_baseline_holdout_passes=sum(r['passed'] for r in rows if r['split']=='holdout' and r['method']=='tuned-baseline'),
              min_holdout_energy_ratio=min(p['baseline_over_goal_energy_cost'] for p in hp),max_holdout_energy_ratio=max(p['baseline_over_goal_energy_cost'] for p in hp),
              comparisons=pairs,selected_baseline_rtol=selection,
              goal_undercovered_items=sum(float(r['actual_abs_error_A_m2'])>float(r['estimated_error_A_m2']) for r in details if r['method']=='goal'),
              max_quad_difference=max(a['quad_reference_relative_difference'] for a in audits),max_mesh_difference=max(a['mesh_relative_difference'] for a in audits))
 (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');plot(root,rows,pairs)
 return summary


def plot(root,rows,pairs):
 plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.2,'savefig.dpi':170})
 held=[p for p in pairs if p['split']=='holdout'];x=np.arange(len(held))
 fig,ax=plt.subplots(figsize=(10,4))
 ax.bar(x,[p['baseline_over_goal_energy_cost'] for p in held]);ax.axhline(1,color='k',ls='--')
 ax.set_xticks(x,[p['context'] for p in held],rotation=22,ha='right');ax.set(ylabel='Tuned baseline / goal energy evaluations',title='Above 1 favors goal; below 1 favors tuned baseline')
 fig.tight_layout();fig.savefig(root/'heldout_cost.png',bbox_inches='tight');plt.close(fig)
 fig,axs=plt.subplots(1,2,figsize=(11,4))
 for ax,task in zip(axs,['cv','decision']):
  for method,marker in [('goal','o'),('tuned-baseline','s'),('conservative-baseline','^')]:
   rs=[r for r in rows if r['split']=='holdout' and r['task']==task and r['method']==method]
   ax.scatter([r['energy_evaluations'] for r in rs],[r['actual_target_error']*100 for r in rs],label=method,marker=marker,s=55)
  ax.axhline(5 if task=='cv' else 1,color='k',ls='--');ax.set(xscale='log',xlabel='Total energy evaluations (same kernel)',ylabel='Target error (%)',title='Fixed-sample CV' if task=='cv' else 'Finite-set selection regret');ax.legend(fontsize=7)
 fig.tight_layout();fig.savefig(root/'heldout_error_cost.png',bbox_inches='tight');plt.close(fig)
