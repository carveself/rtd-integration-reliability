from pathlib import Path
import sys,json,unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from models import Layers,model
from integration import PanelIntegral
from targets import cv_envelope,coefficient_of_variation,goal_cv,goal_decision,budget_lockstep
from benchmark import choose_baseline
from negf import transport,integrate_current
CFG=json.loads((Path(__file__).resolve().parents[1]/'protocol.json').read_text())

class SyntheticState:
 def __init__(self,true,sign=1.):self.true=true;self.sign=sign;self.e=.05;self.evaluations=0
 @property
 def value(self):return self.true+self.sign*.8*self.e
 @property
 def error(self):return self.e
 def refine(self):self.e*=.3;self.evaluations+=48
 def finish(self,rtol):
  while self.error>rtol*abs(self.value):self.refine()

class AnalyticPanels(PanelIntegral):
 def __init__(self):
  self.cfg=CFG;self.pref=1.;self.tail=0.;self.evaluations=0;self.refinements=0
  self.l=np.arange(10)/10;self.r=self.l+.1;self.v,self.e=self.panels(self.l,self.r)
 def values(self,es):self.evaluations+=es.size;return 1/((es-.453)**2+.003**2)

class Checks(unittest.TestCase):
 def test_conditional_cv_envelope_covers_bounded_perturbations(self):
  rng=np.random.default_rng(513)
  for _ in range(100):
   true=rng.uniform(.8,1.2,12);eps=rng.uniform(.001,.01,12);observed=true+rng.uniform(-1,1,12)*eps
   lo,hi=cv_envelope(observed,eps);actual=coefficient_of_variation(true)
   self.assertLessEqual(lo,actual);self.assertGreaterEqual(hi,actual)
 def test_zero_error_collapses_envelope(self):
  y=np.array([1.,1.1,.9]);lo,hi=cv_envelope(y,np.zeros(3));self.assertAlmostEqual(lo,coefficient_of_variation(y));self.assertEqual(lo,hi)
 def test_uncertain_mean_does_not_claim_finite_cv(self):
  self.assertTrue(np.isinf(cv_envelope(np.ones(3),np.ones(3)*2)[1]))
 def test_invalid_error_vector_rejected(self):
  with self.assertRaises(ValueError):cv_envelope(np.ones(3),[-1.,0.,0.])
 def test_goal_cv_condition_on_synthetic_true_bounds(self):
  truths=np.linspace(.98,1.02,10);st=[SyntheticState(t,(-1)**i) for i,t in enumerate(truths)]
  out=goal_cv(st,CFG);actual=coefficient_of_variation(truths)
  self.assertLess(abs(out['estimate']/actual-1),.05)
  self.assertLessEqual(out['lower'],actual);self.assertGreaterEqual(out['upper'],actual)
 def test_near_zero_cv_absolute_mode(self):
  st=[SyntheticState(1.,(-1)**i) for i in range(8)];out=goal_cv(st,CFG)
  self.assertEqual(out['mode'],'absolute');self.assertLess(out['estimate'],CFG['cv_absolute_budget']);self.assertLess(out['upper'],CFG['cv_near_zero'])
 def test_small_nonzero_cv_not_misclassified_as_absolute(self):
  truths=np.linspace(.9998,1.0002,8);st=[SyntheticState(t,(-1)**i) for i,t in enumerate(truths)]
  out=goal_cv(st,CFG)
  self.assertEqual(out['mode'],'relative')
  self.assertLess(abs(out['estimate']/coefficient_of_variation(truths)-1),.05)
 def test_goal_decision_finds_compatible_best(self):
  st=[SyntheticState(1.,1),SyntheticState(1.03,-1),SyntheticState(.8,1)];out=goal_decision(st,CFG)
  self.assertEqual(out['chosen'],1);self.assertIn(1,out['possible']);self.assertLessEqual(out['regret_estimate'],.01)
 def test_budget_lockstep_same_target_condition(self):
  st=[SyntheticState(1.,1),SyntheticState(1.03,-1),SyntheticState(.8,1)]
  out=budget_lockstep(st,CFG,'decision');self.assertEqual(out['chosen'],1);self.assertLessEqual(out['regret_estimate'],.01)
 def test_development_selection_ignores_holdout(self):
  rows=[dict(split='development',task='cv',rtol=.1,passed=True,energy_evaluations=5),dict(split='development',task='cv',rtol=.01,passed=True,energy_evaluations=10),dict(split='holdout',task='cv',rtol=.1,passed=False,energy_evaluations=1)]
  self.assertEqual(choose_baseline(rows,[.1,.01],'cv'),.1)
 def test_cached_gauss_against_exact_lorentzian_integral(self):
  st=AnalyticPanels();st.finish(1e-8)
  exact=(np.arctan((1-.453)/.003)-np.arctan(-.453/.003))/.003
  self.assertLess(abs(st.value/exact-1),1e-8)
  self.assertEqual(st.evaluations,240+st.refinements*192)
 def test_multiwell_free_chain_transparency(self):
  d=model(dict(kind='triple',barrier_nm=3.,well_nm=5.,second_well_nm=5.5),height=0.)
  np.testing.assert_allclose(transport(d,[.01,.08,.2])['T'],1,atol=2e-12)
 def test_new_integrator_matches_frozen_reference(self):
  c=dict(kind='triple',barrier_nm=3.,well_nm=5.,second_well_nm=5.5);d=model(c)
  st=PanelIntegral(d,.12,250.,CFG);st.finish(1e-6)
  ref=integrate_current(d,.12,250.,rtol=1e-9,panel_eV=.0005)
  self.assertLess(abs(st.value/ref['J_A_m2']-1),2e-6)

if __name__=='__main__':unittest.main()
