# Benefits and limitations of target-aware quadrature for model resonant-tunneling devices

Exploratory research brief for internal discussion. Not a submission-ready manuscript. No authors, affiliations, measurements, or peer-review endorsements are asserted here.

## Abstract

We evaluate whether allocating energy-quadrature effort according to downstream statistical and design targets is advantageous for prescribed-potential resonant-tunneling models. A target-aware prototype and several baselines share the same cached Gauss-panel kernel. Development-only tolerance selection is followed by six initially held-out tasks and two additional confirmation tasks introduced after internal review. Both the prototype and a uniform target-budget baseline meet the stated numerical targets on these eight tasks. The prototype reduces their aggregate energy-evaluation count by approximately 2.10%, which does not establish a substantial general efficiency advantage. Five of 308 pointwise error estimates across all tasks underpredict the reference error, invalidating an unconditional certification claim. A post-review shifted-grid diagnostic removes observed undercoverage on these cases at approximately 86.6% additional evaluation cost. These results motivate further investigation of affordable error indicators rather than a claim of a validated new high-efficiency algorithm.

## Research question

This study concerns numerical control of fixed-sample coefficients of variation and discrete candidate selection. It does not infer fabrication variability from measurements. Goal-oriented adaptivity and adaptive transport quadrature have prior literature; the present prototype is an exploratory comparison, and its novelty is unresolved.

## Methods

The transport model is coherent, ballistic, single-band, constant-mass and non-self-consistent. The electrostatic profile is prescribed. Layer sequences include double-barrier structures and a triple-barrier, two-well extension. Random barrier-height inputs follow a synthetic normal distribution. The physical benchmark comprises seven 32-item statistical tasks and four 21-candidate design tasks.

The prototype prioritizes contributions to a conditional CV perturbation envelope or to a candidate-selection regret estimate. The competing methods include development-tuned uniform current tolerances, a conservative current-tolerance method and uniform scheduling under the same target envelopes. All energy points from both quadrature rules, initialization and refinement are counted. Reference solutions are used offline, not by the stopping rules.

The CV envelope follows standard norm inequalities if its pointwise input errors are genuine bounds. In this implementation they are estimated by differences between quadrature rules and are not proven bounds. The shifted-grid diagnostic was evaluated after inspecting failures; it is not prospective validation.

## Results

The prototype and uniform target-budget scheduler pass all eight non-development tasks. The development-tuned current-tolerance baseline passes seven, failing a selection task with approximately 6.05% reference-current loss. However, the stronger target-budget scheduler also avoids this failure. Its aggregate count is 485688 energy evaluations, compared with 475512 for the prototype. Counts across this fixed mixture of structures are an implementation work proxy, not a universal complexity estimate or a statistically demonstrated wall-time speedup.

Initialization accounts for approximately 49.8–97.2% of prototype evaluations on the non-development tasks. Pointwise undercoverage occurs in five items across all eleven tasks; the largest actual-to-estimated error ratio is approximately 16.74. A shifted-grid diagnostic adds 617856 evaluations to the prototype's original 713376 across all tasks. The observed absence of undercoverage after this diagnostic does not imply a guaranteed future coverage probability.

## Discussion

The current evidence supports the usefulness of separating downstream target accuracy from per-current tolerances, but does not establish a compelling new method. A fixed-sample CV accuracy budget must also be distinguished from Monte Carlo uncertainty about a population CV. The small test collection, post-review additions, synthetic input model and lack of an independently implemented finite-bias continuum solver limit interpretation.

A publication-oriented continuation would require a clearly differentiated and reliable error indicator, fair comparison with the closest published spike-aware methods, genuinely new validation cases and an accounting of all detection and calibration costs. Current results should be retained as feasibility and failure evidence rather than presented as a successful algorithm paper.

## Reproducibility and contribution record

Protocols, source snapshots, raw point errors, target trajectories, reference audits and source hashes are included in this local research package. The code and this brief were prepared with AI assistance. A future author must accurately distinguish reference implementation, independent derivation, debugging and new research contributions. Nothing in this brief claims experimental validation, submission or acceptance.
