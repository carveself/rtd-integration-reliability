# 本轮新增的文献约束

检索日期2026-10-23。本轮仍为定向查重，不是完整系统综述。以下只依据已打开的原始作者摘要和元数据，不声称已经逐项复现论文方法。

- Scarabosio、Wohlmuth、Oden、Faghihi，*Goal-Oriented Adaptive Modeling of Random Heterogeneous Media and Model-Based Multilevel Monte Carlo Methods*，作者预印本2018、修订2019，[原始来源](https://arxiv.org/abs/1808.01923)。该工作已按目标量误差构造自适应模型与多层抽样。不能把“关注目标量而不是每个底层解的误差”本身作为本项目创新。
- Beck、Liu、von Schwerin、Tempone，*Goal-Oriented Adaptive Finite Element Multilevel Monte Carlo with Convergence Rates*，2022，[原始来源](https://arxiv.org/abs/2206.10314)，相关DOI:10.1016/j.cma.2022.115582。已有按目标量、实现和期望精度安排求解停止的工作。应用方程与本项目不同，不等于已经证明两种方法完全相同，也不支持声称我们首次提出此思想。

上一轮的2007 NEGF自适应积分、2010尖峰求积和2021/2025 RTD变异文献仍适用。其查重记录已随本包保留在PILOT_LITERATURE_AUDIT.md。

2010论文的机构记录可查，但本轮获取作者论文全文的尝试未成功，未凭摘要猜造算法。故未完成该基线是当前论文证据缺口，不能通过省略它来声称优于全部成熟方法。

当前实现只是已有目标量控制思想在简化输运模型中的比较原型。是否形成新方法，需要继续核查最接近方法、给出实质差异，并证明收益。代码行数、留出任务数量和测试通过都不能代替创新性判断。
