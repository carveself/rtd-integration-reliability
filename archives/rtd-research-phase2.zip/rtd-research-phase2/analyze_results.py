"""Post-analysis only: preserve all frozen raw benchmark measurements."""
from pathlib import Path
import csv,json,argparse
import numpy as np
from scipy.constants import Boltzmann,elementary_charge
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def read(path):return list(csv.DictReader(path.open()))
def write(path,rows):
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def analyze(root,results=None):
 cfg=json.loads((root/'protocol.json').read_text());p=Path(results) if results is not None else root/'results';raw=read(p/'benchmark.csv');samples=read(p/'sample_errors.csv');pairs=read(p/'comparison.csv')
 cases={c['id']:c for split in ['development','holdout','confirmation'] for c in cfg[split]}
 cases.update({c['id']:c for c in cfg['designs']})
 floors=[]
 for r in raw:
  if r['method']!='goal':continue
  c=cases[r['context']];n=cfg['samples'] if r['task']=='cv' else len(c['wells_nm'])
  hi=.08+30*Boltzmann*c['temperature_K']/elementary_charge
  initial=n*int(np.ceil((hi-1e-12)/cfg['initial_panel_eV']))*24
  floors.append(dict(context=r['context'],split=r['split'],task=r['task'],initial_energy_evaluations=initial,
                     total_goal_evaluations=int(r['energy_evaluations']),initial_fraction=initial/int(r['energy_evaluations'])))
 write(p/'initialization_floor.csv',floors)
 under=[]
 for r in samples:
  if r['method']=='goal' and float(r['actual_abs_error_A_m2'])>float(r['estimated_error_A_m2']):
   under.append({**r,'actual_to_estimated_error_ratio':float(r['actual_abs_error_A_m2'])/float(r['estimated_error_A_m2'])})
 write(p/'undercoverage.csv',under)
 held=[r for r in raw if r['split']!='development']
 totals={m:sum(int(r['energy_evaluations']) for r in held if r['method']==m) for m in ['goal','tuned-baseline','budget-lockstep','conservative-baseline']}
 result=dict(undercovered_goal_items=len(under),goal_items=sum(r['method']=='goal' for r in samples),
             worst_error_underestimate_factor=max(float(r['actual_to_estimated_error_ratio']) for r in under),
             held_context_energy_totals=totals,
             aggregate_goal_saving_vs_tuned=1-totals['goal']/totals['tuned-baseline'],
             aggregate_goal_saving_vs_budget=1-totals['goal']/totals['budget-lockstep'],
             holdout_initialization_fraction_range=[min(r['initial_fraction'] for r in floors if r['split']!='development'),max(r['initial_fraction'] for r in floors if r['split']!='development')],
             maximum_fixed_sample_goal_cv_relative_error=max(float(r['actual_target_error']) for r in raw if r['method']=='goal' and r['task']=='cv'))
 (p/'advisor_analysis.json').write_text(json.dumps(result,indent=2)+'\n')
 plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.2,'savefig.dpi':170})
 fig,axs=plt.subplots(1,2,figsize=(11,4))
 for task,color in [('cv','tab:blue'),('decision','tab:orange')]:
  rr=[r for r in samples if r['method']=='goal' and r['task']==task]
  x=np.array([float(r['estimated_error_A_m2']) for r in rr]);y=np.maximum([float(r['actual_abs_error_A_m2']) for r in rr],1e-12)
  axs[0].loglog(x,y,'.',label=task,color=color)
 low=1.;high=max(float(r['actual_abs_error_A_m2']) for r in samples if r['method']=='goal')*2
 axs[0].plot([low,high],[low,high],'k--');axs[0].set(xlabel='Estimated point error (A/m²)',ylabel='Actual error vs reference (A/m²)',title='Above diagonal: estimator undercovers');axs[0].legend()
 rr=[r for r in floors if r['split']!='development'];x=np.arange(len(rr));axs[1].bar(x,[100*r['initial_fraction'] for r in rr])
 axs[1].set_xticks(x,[r['context'] for r in rr],rotation=35,ha='right');axs[1].set(ylabel='Initial / total goal evaluations (%)',title='Initialization limits scheduling savings',ylim=(0,105))
 fig.tight_layout();fig.savefig(p/'advisor_diagnostics.png',bbox_inches='tight');plt.close(fig)
 print(json.dumps(result,indent=2))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--results',type=Path);args=parser.parse_args();analyze(Path(__file__).resolve().parent,args.results)
