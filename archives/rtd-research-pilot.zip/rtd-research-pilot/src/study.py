"""Paired experiment separating synthetic parameter variability from quadrature error."""
from pathlib import Path
import sys,json,csv,hashlib,time
from dataclasses import replace
import numpy as np
from scipy.integrate import trapezoid,quad
from scipy.signal import find_peaks
from scipy.optimize import minimize_scalar
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from negf import Device,transport,supply,current_prefactor,integrate_current,KB,Q
from reference import direct_banded
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':10,'figure.dpi':110,'savefig.dpi':160,'axes.grid':True,'grid.alpha':.2,
                     'axes.spines.top':False,'axes.spines.right':False})


def save_csv(path,rows):
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def uniform_current(d,bias,temp,step,offset,high):
    # Anchor the infinite grid at step*offset, but preserve identical actual endpoints.
    low=max(0.,-bias)+1e-12
    grid=np.arange(offset*step,high,step); grid=grid[grid>low]
    es=np.unique(np.r_[low,grid,high])
    trans=transport(d,es,bias)['T']
    return float(current_prefactor(d.mass)*trapezoid(trans*supply(es,bias,temp,d.mu_eV),es)),len(es)


def cv(x): return float(np.std(x,ddof=1)/np.mean(x))


def inverted_pairs(reference,approx):
    i,j=np.triu_indices(len(reference),1)
    return float(np.mean((reference[i]-reference[j])*(approx[i]-approx[j])<0))


def summarize_pair(ref,approx):
    err=approx-ref
    vr=np.var(ref,ddof=1); ve=np.var(err,ddof=1); co=np.cov(ref,err,ddof=1)[0,1]
    return dict(reference_cv=cv(ref),coarse_cv=cv(approx),cv_ratio=cv(approx)/cv(ref),
                mean_relative_bias=float(np.mean(approx)/np.mean(ref)-1),
                pair_inversion_fraction=inverted_pairs(ref,approx),
                variance_reference=float(vr),variance_error=float(ve),twice_covariance=float(2*co),
                variance_coarse=float(np.var(approx,ddof=1)),
                variance_identity_relative_error=float(abs(np.var(approx,ddof=1)-vr-ve-2*co)/np.var(approx,ddof=1)))


def reference_pair(d,bias,temp,cfg):
    a=integrate_current(d,bias,temp,rtol=cfg['reference_rtol'],panel_eV=cfg['reference_panel_eV'])
    b=integrate_current(d,bias,temp,rtol=cfg['reference_rtol'],panel_eV=cfg['check_panel_eV'])
    delta=abs(a['J_A_m2']/b['J_A_m2']-1)
    if delta>1e-6: raise RuntimeError(f'Reference panel check failed: {delta}')
    return a,b,delta


def independent_quad(d,bias,temp,high):
    # Dense scouting plus optimized peak locations seed a *separate* QUADPACK integral.
    es=np.linspace(1e-9,high,4001); ts=transport(d,es,bias)['T']
    ids,_=find_peaks(ts,prominence=1e-5)
    peaks=[]
    for k in ids:
        opt=minimize_scalar(lambda e:-transport(d,[e],bias)['T'][0],
                            bounds=(es[k-1],es[k+1]),method='bounded',options={'xatol':1e-14})
        peaks.append(opt.x)
    points=np.unique(np.r_[np.linspace(0,high,151)[1:-1],peaks])
    f=lambda e:float(transport(d,[e],bias)['T'][0]*supply(e,bias,temp,d.mu_eV))
    integ,error,info=quad(f,0,high,points=points,epsabs=1e-13,epsrel=2e-9,limit=2000,full_output=1)
    return float(integ*current_prefactor(d.mass)),float(error*current_prefactor(d.mass)),int(info['neval'])


def run(root,cfg):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    rows=[];references=[];audit=[];cohorts={}
    t0=time.perf_counter()
    # Identical parameter draws across barrier widths are intentional common random numbers.
    draws=[(seed,i,float(h)) for seed in cfg['seeds'] for i,h in enumerate(
        np.random.default_rng(seed).normal(cfg['height_mean_eV'],cfg['height_sigma_eV'],cfg['samples_per_seed']))]
    for barrier in cfg['barriers_nm']:
        per=[]
        for seed,i,height in draws:
            d=Device(barrier_nm=barrier,height_eV=height,spacing_nm=cfg['spacing_nm'])
            a,b,delta=reference_pair(d,cfg['bias_V'],cfg['temperature_K'],cfg)
            legacy=integrate_current(d,cfg['bias_V'],cfg['temperature_K'])
            ref=float(b['J_A_m2'])
            references.append(dict(barrier_nm=barrier,seed=seed,sample=i,height_eV=height,J_reference_A_m2=ref,
                                   panel_relative_difference=delta,legacy_adaptive_relative_error=float(legacy['J_A_m2']/ref-1),
                                   tail_bound_A_m2=float(b['tail_bound_A_m2']),reference_evaluations=b['evaluations']))
            vector=[]
            for step in cfg['steps_eV']:
                for offset in cfg['offsets']:
                    value,n=uniform_current(d,cfg['bias_V'],cfg['temperature_K'],step,offset,b['Emax_eV'])
                    rows.append(dict(barrier_nm=barrier,seed=seed,sample=i,height_eV=height,step_eV=step,offset=offset,
                                     J_reference_A_m2=ref,J_grid_A_m2=value,evaluations=n,relative_error=value/ref-1))
                    vector.append(value)
            per.append((seed,ref,vector))
        cohorts[barrier]=per
        print('Completed ensemble, barrier',barrier,'nm;',len(per),'paired samples',flush=True)
        # Min/median/max actual heights: data-independent selection rule, not worst-error cherry picking.
        ordered=sorted(draws,key=lambda z:z[2])
        for seed,i,height in [ordered[0],ordered[len(ordered)//2],ordered[-1]]:
            d=Device(barrier_nm=barrier,height_eV=height)
            a,b,delta=reference_pair(d,cfg['bias_V'],cfg['temperature_K'],cfg)
            q,qe,qn=independent_quad(d,cfg['bias_V'],cfg['temperature_K'],b['Emax_eV'])
            fine=integrate_current(replace(d,spacing_nm=.05),cfg['bias_V'],cfg['temperature_K'],rtol=1e-9,panel_eV=.0005)
            e=.031; td=direct_banded(d,e,cfg['bias_V']); tr=transport(d,[e],cfg['bias_V'])['T'][0]
            audit.append(dict(barrier_nm=barrier,height_eV=height,quad_J_A_m2=q,gauss_J_A_m2=float(b['J_A_m2']),
                              quad_relative_difference=abs(q/b['J_A_m2']-1),quad_estimated_error_A_m2=qe,quad_evaluations=qn,
                              fine_mesh_J_A_m2=float(fine['J_A_m2']),mesh_relative_difference=abs(b['J_A_m2']/fine['J_A_m2']-1),
                              direct_T_difference=float(abs(td-tr))))
    save_csv(root/'ensemble_samples.csv',references);save_csv(root/'grid_samples.csv',rows);save_csv(root/'reference_audit.csv',audit)
    # Pooled and separate-seed analyses; numerical origins are never randomized within an ensemble.
    summaries=[];boot=np.random.default_rng(991723)
    for barrier,per in cohorts.items():
        for seed in [0,*cfg['seeds']]:
            subset=per if seed==0 else [z for z in per if z[0]==seed]
            ref=np.array([z[1] for z in subset]); mat=np.array([z[2] for z in subset])
            indices=boot.integers(0,len(ref),(cfg['bootstrap_repeats'],len(ref)))
            for j,(step,offset) in enumerate((s,o) for s in cfg['steps_eV'] for o in cfg['offsets']):
                ap=mat[:,j]; summary=summarize_pair(ref,ap)
                br=ref[indices];ba=ap[indices]
                ratio=(np.std(ba,axis=1,ddof=1)/np.mean(ba,axis=1))/(np.std(br,axis=1,ddof=1)/np.mean(br,axis=1))
                lo,hi=np.quantile(ratio,[.025,.975])
                summaries.append(dict(barrier_nm=barrier,seed=seed,n=len(ref),step_eV=step,offset=offset,
                                      cv_ratio_bootstrap_low=float(lo),cv_ratio_bootstrap_high=float(hi),**summary))
    save_csv(root/'ensemble_statistics.csv',summaries)
    designs=[]
    for well in cfg['design_wells_nm']:
        d=Device(barrier_nm=5.,well_nm=well);a,b,delta=reference_pair(d,cfg['bias_V'],cfg['temperature_K'],cfg)
        for step in cfg['steps_eV']:
            for offset in cfg['offsets']:
                val,n=uniform_current(d,cfg['bias_V'],cfg['temperature_K'],step,offset,b['Emax_eV'])
                designs.append(dict(well_nm=well,step_eV=step,offset=offset,J_reference_A_m2=float(b['J_A_m2']),J_grid_A_m2=val))
    save_csv(root/'design_samples.csv',designs)
    decisions=[]
    for step in cfg['steps_eV']:
        for offset in cfg['offsets']:
            sub=[z for z in designs if z['step_eV']==step and z['offset']==offset]
            ref=np.array([z['J_reference_A_m2'] for z in sub]);app=np.array([z['J_grid_A_m2'] for z in sub]);ir=np.argmax(ref);ia=np.argmax(app)
            decisions.append(dict(step_eV=step,offset=offset,reference_best_well_nm=sub[ir]['well_nm'],
                                  selected_well_nm=sub[ia]['well_nm'],selection_regret=float(1-ref[ia]/ref[ir]),
                                  pair_inversion_fraction=inverted_pairs(ref,app)))
    save_csv(root/'design_decisions.csv',decisions)
    # Null experiment: one *identical* device, only deterministic grid origin changes.
    null=[];d=Device(barrier_nm=5.);a,b,_=reference_pair(d,cfg['bias_V'],cfg['temperature_K'],cfg)
    for off in np.arange(16)/16:
        val,n=uniform_current(d,cfg['bias_V'],cfg['temperature_K'],.001,float(off),b['Emax_eV'])
        null.append(dict(offset=float(off),J_grid_A_m2=val,J_reference_A_m2=float(b['J_A_m2'])))
    save_csv(root/'identical_device_null.csv',null)
    primary=[z for z in summaries if z['barrier_nm']==5. and z['seed']==0 and z['step_eV']==.001 and z['offset']==0][0]
    broad=[z for z in summaries if z['barrier_nm']==3. and z['seed']==0 and z['step_eV']==.001 and z['offset']==0][0]
    summary=dict(status='feasibility evidence only; novelty and publication readiness unresolved',
                 independent_parameter_realizations_per_cohort=len(draws),barrier_cohorts=len(cohorts),paired_grid_evaluations=len(rows),
                 primary_5nm_1meV_zero_offset=primary,broad_control_3nm=broad,
                 max_reference_panel_relative_difference=max(z['panel_relative_difference'] for z in references),
                 max_legacy_adaptive_relative_error=max(abs(z['legacy_adaptive_relative_error']) for z in references),
                 max_independent_quad_relative_difference=max(z['quad_relative_difference'] for z in audit),
                 max_mesh_relative_difference_on_audited_cases=max(z['mesh_relative_difference'] for z in audit),
                 max_selection_regret=max(z['selection_regret'] for z in decisions),
                 identical_device_grid_origin_cv=cv(np.array([z['J_grid_A_m2'] for z in null])),
                 elapsed_seconds=time.perf_counter()-t0)
    (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    plots(root,summaries,designs,decisions,null,cohorts)
    return summary


def plots(root,stats,designs,decisions,null,cohorts):
    fig,axs=plt.subplots(1,3,figsize=(13,3.8))
    for ax,(barrier,per) in zip(axs,cohorts.items()):
        ref=np.array([z[1] for z in per]);app=np.array([z[2][8] for z in per]) # step 1meV, origin 0
        ax.scatter(ref/1e4,app/1e4,s=12,alpha=.6)
        low=min(ref.min(),app.min())/1e4;high=max(ref.max(),app.max())/1e4
        ax.plot([low,high],[low,high],'k--');ax.set(xlabel='Reference J (A/cm²)',ylabel='1 meV grid J (A/cm²)',title=f'Barrier {barrier:g} nm')
        ax.ticklabel_format(style='sci',axis='both',scilimits=(0,0))
    fig.tight_layout();fig.savefig(root/'paired_current.png',bbox_inches='tight');plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4))
    for b in cohorts:
        sub=[z for z in stats if z['barrier_nm']==b and z['seed']==0 and z['offset']==0]
        ax.loglog([z['step_eV']*1e3 for z in sub],[z['cv_ratio'] for z in sub],'o-',label=f'{b:g} nm')
    ax.axhline(1,color='k',ls='--');ax.set(xlabel='Uniform energy step (meV)',ylabel='Estimated CV / reference CV',title='Apparent variability depends on energy resolution');ax.legend()
    fig.tight_layout();fig.savefig(root/'variability_distortion.png',bbox_inches='tight');plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11,4))
    sub=[z for z in designs if z['step_eV']==.001 and z['offset']==0]
    axs[0].plot([z['well_nm'] for z in sub],[z['J_reference_A_m2']/1e4 for z in sub],'k-',label='Reference')
    for off in [0.,.25,.5,.75]:
        sub=[z for z in designs if z['step_eV']==.001 and z['offset']==off]
        axs[0].plot([z['well_nm'] for z in sub],[z['J_grid_A_m2']/1e4 for z in sub],'o-',ms=3,label=f'Origin {off:g}')
    axs[0].set(xlabel='Well width (nm)',ylabel='J at 0.1 V (A/cm²)',title='Same 21 candidates; 1 meV sampling');axs[0].legend(fontsize=8)
    for off in [0.,.25,.5,.75]:
        sub=[z for z in decisions if z['offset']==off]
        axs[1].plot([z['step_eV']*1e3 for z in sub],[z['selection_regret']*100 for z in sub],'o-',label=f'Origin {off:g}')
    axs[1].set(xlabel='Uniform energy step (meV)',ylabel='Reference-current loss of selection (%)',title='Discrete choice regret, not global optimum');axs[1].legend(fontsize=8)
    fig.tight_layout();fig.savefig(root/'design_ranking.png',bbox_inches='tight');plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11,4))
    x=[z['offset'] for z in null];y=[z['J_grid_A_m2']/z['J_reference_A_m2'] for z in null]
    axs[0].plot(x,y,'o-');axs[0].axhline(1,color='k',ls='--');axs[0].set(xlabel='Energy grid offset / step',ylabel='J grid / J reference',title='Identical device; no parameter randomness')
    sub=[z for z in stats if z['barrier_nm']==5 and z['seed']==0 and z['step_eV']==.001 and z['offset']==0][0]
    vals=np.array([sub['variance_reference'],sub['variance_error'],sub['twice_covariance'],sub['variance_coarse']])/sub['variance_reference']
    axs[1].bar(['Var(ref)','Var(error)','2 Cov','Var(grid)'],vals);axs[1].set(ylabel='Variance / Var(reference)',title='Paired variance identity; covariance retained')
    fig.tight_layout();fig.savefig(root/'error_attribution.png',bbox_inches='tight');plt.close(fig)
