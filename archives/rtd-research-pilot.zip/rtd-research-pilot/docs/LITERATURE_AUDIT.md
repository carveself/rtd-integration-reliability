# 选题查重与贡献边界

检索日期：2026-10-22。检索工具为网页搜索，并打开作者论文、机构仓储、出版社或 PubMed Central 原文页。下表是定向查重，不是完整系统综述；没有查全 IEEE Xplore、Scopus、Web of Science 或所有引用链，不能据此宣布“首次”。

## 已核查的主要原始工作

| 原始文献 | 实际核查范围 | 已有贡献及对本选题的约束 |
|---|---|---|
| Baumgartner et al., **Adaptive Energy Integration of Non-Equilibrium Green’s Functions**, NSTI-Nanotech 2007, vol.3, pp.145–148 ([作者机构 PDF](https://www.iue.tuwien.ac.at/pdf/ib_2007/hashed_links/5d4PPhrpGwMLGJjaQJrCY_us.pdf)) | 全文方法与结果文字 | 比较多种 NEGF 自适应积分和误差控制。不能把“自适应积分能解析窄峰”作为新意。 |
| Agarwal et al., **Adaptive quadrature for sharply spiked integrands**, J. Comput. Electron. 9, 252–255 (2010), DOI:10.1007/s10825-010-0338-3 ([Purdue 原始记录](https://docs.lib.purdue.edu/nanopub/722/)) | 机构记录、摘要；未获得可用出版社全文 | 已针对尖峰积分比较多种求积器。本预实验没有实现或击败其算法，不能宣称普遍优于已有方法。 |
| Gao et al., **Efficient self-consistent quantum transport simulator for quantum devices**, J. Appl. Phys. 115, 133707 (2014), DOI:10.1063/1.4870288 ([作者预印本](https://arxiv.org/abs/1403.7564)) | 作者摘要与论文元数据 | CBR–Poisson、自洽与加速已有成熟研究；“写一个一维自洽 NEGF”本身不是充分创新。 |
| Decleer & Vande Ginste, **Uncertainty Quantification of Charge Transfer through a Nanowire Resonant-Tunneling Diode with an ADHIE-FDTD method**, NAP 2021 ([作者机构全文](https://backoffice.biblio.ugent.be/download/8722989/8724572)) | 全文模型、变量分布与方法 | 已研究相关势垒厚度随机性和输运；不能把 RTD 加 Monte Carlo、加厚度相关性本身作为新意。 |
| Acharya et al., **Impact of interface roughness correlation on resonant tunnelling diode variation**, Sci. Rep. 15, 26815 (2025), DOI:10.1038/s41598-025-07720-0 ([原文 PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12287518/)) | 全文模型、数值参数、讨论 | 已用自洽 NEGF–Poisson 研究各向异性界面粗糙。本文使用一维合成高度扰动，不能替代其模型，也不能凭我们的粗网格反例推断该论文不可靠。 |
| Conrads & Di Napoli, **RSE of a Quantum Transport Code and its Effects**, arXiv:2605.21334v2 (2026) ([作者预印本](https://arxiv.org/abs/2605.21334v2)) | 摘要、版本和元数据；非同行评审状态未核实 | 量子输运代码验证和软件质量已有专门工作；“测试很多”不能独立构成新的器件物理贡献。 |

补充发现：*Interface roughness in Resonant Tunnelling Diodes for physically unclonable functions*, Solid-State Electronics 228 (2025) 109131, DOI:10.1016/j.sse.2025.109131。搜索返回出版社摘要，直接正文访问受限；只用于提醒“粗糙度+PUF”也已有工作，不据此复述详细定量结果。

## 当前候选问题

**在窄共振器件的随机参数模拟中，如何控制数值误差，使变异估计与设计排序的结论稳定？**

可能的论文贡献必须是“针对统计量/决策的误差预算或新规律”，而不是再次证明窄峰容易漏采样。现在的配对实验只是检验这个问题是否有值得继续追的实际后果。

## 尚未解决的查重问题

- 已有尖峰求积、goal-oriented adaptivity（面向目标量的自适应）和多层 Monte Carlo 文献中，是否已给出同类统计误差预算？需要沿这些术语继续查阅。
- 是否已有量子输运论文明确联合报告数值积分误差、变异估计偏差与设计选择损失？本次定向检索未形成充分证据判断。
- 本预实验没有提出已验证的新求积算法。简单方差恒等式、排序翻转率、bootstrap 都是现有方法，不以新理论名义包装。

## 检索日志与排除理由

检索串包括：`resonant tunneling diode interface roughness correlation variability`、`NEGF adaptive quadrature current`、`quantum transport numerical error variability`、`resonant tunneling uncertainty quantification`、`resonant tunneling numerical integration design ranking`，并补充 2025/2026 的原始来源检索。

命中的 WKB 高振荡误差分析、RTD 振荡器电路正交相位、量子热输运等工作不直接回答当前问题，未作为“同类方法已比较”的证据。没有把搜索未命中当作不存在先例。
