from pathlib import Path
import argparse,json,sys,hashlib,platform
import importlib.metadata as metadata
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'src'))
from study import run


def write_metadata(output):
 files=[root/'run_pilot.py',*[f for folder in ['src','vendor'] for f in (root/folder).glob('*.py')]]
 provenance={'protocol_sha256':hashlib.sha256((root/'protocol.json').read_bytes()).hexdigest(),
             'source_sha256':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
 (output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
 (output/'environment.json').write_text(json.dumps({'python':platform.python_version(),
     **{name:metadata.version(name) for name in ['numpy','scipy','matplotlib']}},indent=2)+'\n')


if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=root/'results');a=p.parse_args()
 config=json.loads((root/'protocol.json').read_text());r=run(a.output,config)
 write_metadata(a.output)
 print(json.dumps(r,indent=2))
