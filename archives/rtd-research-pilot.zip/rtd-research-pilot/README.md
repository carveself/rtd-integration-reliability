# 从教学代码到研究：RTD 统计与设计的数值误差预实验

**这是已运行的选题可行性研究包，不是已经具备投稿条件的论文。**

候选问题：数值积分误差会不会被误认为器件参数变异，甚至改变设计排序？已完成文献查重、两种种子、三种峰宽条件、配对参考、独立积分审计、变异统计和21个有限设计候选对比。用户资源约束：只有个人电脑、纯仿真。

先读 [可行性结论与完整结果](docs/FEASIBILITY_REPORT.md)，再读 [文献审查](docs/LITERATURE_AUDIT.md)、[方法](docs/METHODS.md)、[下一项具体实验](docs/NEXT_EXPERIMENT.md) 和 [投稿前关卡](docs/RESEARCH_GATES.md)。

## 一键复现

Python 3.10+：

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python run_pilot.py --output reproduction/full
python -m unittest discover -s tests -v
```

默认 `python run_pilot.py` 覆盖 `results/` 同名生成文件。相对输出路径以执行目录为基准。完整计算已实际运行；6项针对配对统计、排序与宽峰恢复的测试通过。冻结输运核的来源与范围见 [vendor/PROVENANCE.md](vendor/PROVENANCE.md)。新增实验沿用先前已验证的教学模型，不声称实现所引用论文的全部算法。

## 结果概要

- 三组各128个参数样本、共6144次配对均匀网格电流估计；组间复用相同高度抽样。
- 合成高度分布下，5nm组的电流CV由参考的1.51%变为1meV均匀网格的11.27%；3nm宽峰对照基本正常。
- 既有自适应基线仍然准确：这是当前还不能声称“新方法”的关键反证。
- 21个候选的1meV网格选择损失随偏移为0–6.90%；最粗2meV设置中的最大损失44.60%，两者不要混淆。

![参数变异估计失真](results/variability_distortion.png)

## 文件与证据

- protocol.json：事先保存的参数、种子与比较设置；不是正式公开预注册。
- vendor/：原仓库冻结输运核与独立带状求解参考。
- src/study.py：配对统计、参考审计与绘图。
- results/：7份CSV、4张PNG、summary/provenance/environment JSON。
- references.bib：已核查的原始来源；摘要与全文的核查层次在文献审查中区分。
- docs/EXPLORATION_LOG.txt：保留此前用于选择窄峰条件的探索，避免隐藏选题过程。

输入高度分布是合成假设，不是测得制造分布；模型是给定电势、常质量、相干输运。这里没有验证真实工艺、提出已证实的新算法、完成投稿或获得录用。研究是否能形成论文，取决于后续新意与验证，而不是仓库大小或曲线数量。
