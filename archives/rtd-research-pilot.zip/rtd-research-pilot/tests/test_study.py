from pathlib import Path
import sys,unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from study import summarize_pair,inverted_pairs,cv,uniform_current,Device,transport,integrate_current

class PairedStudyChecks(unittest.TestCase):
 def test_correlated_error_retains_covariance(self):
  y=np.array([1.,2.,4.,8.]);a=3*y+2
  r=summarize_pair(y,a)
  self.assertGreater(r['twice_covariance'],0)
  self.assertLess(r['variance_identity_relative_error'],1e-13)
  self.assertAlmostEqual(r['variance_coarse'],r['variance_reference']+r['variance_error']+r['twice_covariance'])
 def test_constant_relative_bias_preserves_cv_and_rank(self):
  y=np.array([1.,2.,4.,8.]);r=summarize_pair(y,1.15*y)
  self.assertAlmostEqual(r['cv_ratio'],1.)
  self.assertEqual(r['pair_inversion_fraction'],0.)
  self.assertAlmostEqual(r['mean_relative_bias'],.15)
 def test_complete_rank_reversal(self):
  self.assertEqual(inverted_pairs(np.arange(5.),-np.arange(5.)),1.)
 def test_identical_values_have_zero_cv(self):
  self.assertEqual(cv(np.ones(8)),0.)
 def test_resolved_grid_recovers_broad_device(self):
  d=Device();r=integrate_current(d,.1)
  j,n=uniform_current(d,.1,300.,.00025,.25,r['Emax_eV'])
  self.assertLess(abs(j/r['J_A_m2']-1),1e-6)
  self.assertGreater(n,1000)
 def test_matched_contacts_and_conservation(self):
  d=Device(height_eV=0.)
  r=transport(d,[.03,.08,.2])
  np.testing.assert_allclose(r['T'],1.,atol=1e-12)
  np.testing.assert_allclose(r['R']+r['T'],1.,atol=1e-12)
if __name__=='__main__':unittest.main()
